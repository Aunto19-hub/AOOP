package com.seamline.dto;

/**
 * Handed back after the password (or Google) step when a code has been emailed.
 * The browser keeps {@code challengeId} and sends it back with the code.
 */
public record LoginChallenge(String challengeId,
                             String maskedEmail,
                             long expiresInSeconds,
                             long resendAfterSeconds) {
}
