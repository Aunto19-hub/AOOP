package com.seamline.dto;

/**
 * What {@code POST /api/auth/login} hands back. Normally {@code login} is
 * populated straight away. Only if sign-in verification is switched on does the
 * password step yield a {@code challenge} instead, with the token coming from
 * {@code POST /api/auth/login/verify}.
 */
public record SignInResult(boolean otpRequired, LoginChallenge challenge, LoginResponse login) {

    public static SignInResult signedIn(LoginResponse login) {
        return new SignInResult(false, null, login);
    }

    public static SignInResult verificationRequired(LoginChallenge challenge) {
        return new SignInResult(true, challenge, null);
    }
}
