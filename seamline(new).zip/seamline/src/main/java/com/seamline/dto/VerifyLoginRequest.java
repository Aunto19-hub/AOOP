package com.seamline.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/** Sign-in step 2: the challenge from step 1 plus the code that was emailed. */
public record VerifyLoginRequest(

        @NotBlank(message = "Sign-in session is missing. Sign in again.")
        @Size(max = 36)
        String challengeId,

        @NotBlank(message = "Verification code is required")
        @Pattern(regexp = "\\d{6}", message = "The code is 6 digits")
        String code) {
}
