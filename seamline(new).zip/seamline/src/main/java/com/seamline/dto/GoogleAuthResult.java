package com.seamline.dto;

/**
 * What {@code POST /api/auth/google} hands back. Three outcomes:
 * <ul>
 *   <li>the Google email matches an employee and a verification code was emailed —
 *       {@code otpRequired} with a {@code challenge}, same as a password sign-in;</li>
 *   <li>it matches and verification is switched off — {@code login} is populated;</li>
 *   <li>it matches nobody — {@code needsSignup}, and the front end shows the one-time
 *       "create your account" form using the verified {@code email}/{@code suggestedName}.</li>
 * </ul>
 */
public record GoogleAuthResult(boolean needsSignup,
                               boolean otpRequired,
                               String email,
                               String suggestedName,
                               LoginChallenge challenge,
                               LoginResponse login) {

    public static GoogleAuthResult from(SignInResult result) {
        return new GoogleAuthResult(false, result.otpRequired(), null, null, result.challenge(), result.login());
    }

    public static GoogleAuthResult needsSignup(String email, String suggestedName) {
        return new GoogleAuthResult(true, false, email, suggestedName, null, null);
    }
}
