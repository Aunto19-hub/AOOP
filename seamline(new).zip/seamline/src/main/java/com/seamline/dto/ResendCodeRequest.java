package com.seamline.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/** "Resend code" on the sign-in verification step. */
public record ResendCodeRequest(

        @NotBlank(message = "Sign-in session is missing. Sign in again.")
        @Size(max = 36)
        String challengeId) {
}
