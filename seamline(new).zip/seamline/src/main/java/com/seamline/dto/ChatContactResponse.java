package com.seamline.dto;

/** One entry in the "start a direct message" list. */
public record ChatContactResponse(String employeeId, String fullName, String roleLabel) {
}
