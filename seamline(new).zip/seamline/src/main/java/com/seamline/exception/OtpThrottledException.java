package com.seamline.exception;

/** "Resend code" pressed before the cooldown ran out. Mapped to 429 Too Many Requests. */
public class OtpThrottledException extends RuntimeException {

    private final long retryAfterSeconds;

    public OtpThrottledException(long retryAfterSeconds) {
        super("Please wait " + retryAfterSeconds + " seconds before requesting another code.");
        this.retryAfterSeconds = retryAfterSeconds;
    }

    public long getRetryAfterSeconds() {
        return retryAfterSeconds;
    }
}
