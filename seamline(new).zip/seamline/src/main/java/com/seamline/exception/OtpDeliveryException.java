package com.seamline.exception;

/** Thrown when a verification code cannot be delivered because email is not configured on the server. */
public class OtpDeliveryException extends RuntimeException {

    public OtpDeliveryException(String message) {
        super(message);
    }
}
