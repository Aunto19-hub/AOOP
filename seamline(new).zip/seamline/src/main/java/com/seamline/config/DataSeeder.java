package com.seamline.config;

import com.seamline.domain.Employee;
import com.seamline.domain.MachineType;
import com.seamline.domain.Operation;
import com.seamline.domain.Operator;
import com.seamline.domain.Order;
import com.seamline.domain.ProductionLine;
import com.seamline.domain.Role;
import com.seamline.domain.Style;
import com.seamline.dto.RunRequest;
import com.seamline.repository.EmployeeRepository;
import com.seamline.repository.OperatorRepository;
import com.seamline.repository.OrderRepository;
import com.seamline.repository.ProductionLineRepository;
import com.seamline.repository.StyleRepository;
import com.seamline.service.DashboardService;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * Loads the demo factory on first start: two styles with their precedence graphs,
 * four lines, a 14-person roster with a skill matrix, the order book, the sign-in
 * accounts, and one simulated shift per line so every screen has real numbers.
 */
@Component
public class DataSeeder implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataSeeder.class);

    private final SeamlineProperties properties;
    private final PasswordEncoder passwordEncoder;
    private final EmployeeRepository employees;
    private final ProductionLineRepository lines;
    private final StyleRepository styles;
    private final OperatorRepository operators;
    private final OrderRepository orders;
    private final DashboardService dashboardService;

    public DataSeeder(SeamlineProperties properties,
                      PasswordEncoder passwordEncoder,
                      EmployeeRepository employees,
                      ProductionLineRepository lines,
                      StyleRepository styles,
                      OperatorRepository operators,
                      OrderRepository orders,
                      DashboardService dashboardService) {
        this.properties = properties;
        this.passwordEncoder = passwordEncoder;
        this.employees = employees;
        this.lines = lines;
        this.styles = styles;
        this.operators = operators;
        this.orders = orders;
        this.dashboardService = dashboardService;
    }

    @Override
    @Transactional
    public void run(String... args) {
        if (properties.seed() == null || !properties.seed().enabled()) {
            return;
        }
        if (employees.count() > 0) {
            return;
        }

        Style polo = seedStyle("POLO-MEN", "Men's Polo Shirt", poloOperations());
        Style tee = seedStyle("TEE-BASIC", "Basic Crew Tee", teeOperations());

        ProductionLine mainLine = seedLine("Line-07", "Unit 2", 78, polo);
        seedLine("Line-03", "Unit 1", 92, tee);
        seedLine("Line-11", "Unit 2", 71, polo);
        seedLine("Line-14", "Unit 3", 88, tee);

        seedRoster();
        seedEmployees(mainLine);
        seedOrders(polo, tee);
        seedShifts();

        log.info("Seeded demo factory: {} lines, {} styles, {} operators, {} orders",
                lines.count(), styles.count(), operators.count(), orders.count());
        log.info("Open http://localhost:8080 and sign in as farhana.akter@seamline.com, "
                        + "kamal.hossain@seamline.com, rezaul.karim@seamline.com or rahima.begum@seamline.com / {}",
                properties.seed().demoPassword());
    }

    // ------------------------------------------------------------------
    // Styles
    // ------------------------------------------------------------------

    private Style seedStyle(String code, String name, List<OperationSpec> specs) {
        Style style = new Style(code, name);

        // Pass 1: persist the operations themselves.
        specs.forEach(spec -> style.addOperation(new Operation(
                spec.code(), spec.name(), spec.smv(), spec.machineType(), spec.minGrade(), spec.sequenceNo())));
        Style saved = styles.save(style);

        // Pass 2: link the precedence graph now that every operation has an ID.
        Map<String, Operation> byCode = new LinkedHashMap<>();
        saved.getOperations().forEach(operation -> byCode.put(operation.getCode(), operation));
        for (OperationSpec spec : specs) {
            Operation operation = byCode.get(spec.code());
            spec.predecessors().forEach(predecessor -> operation.addPredecessor(byCode.get(predecessor)));
        }
        return styles.save(saved);
    }

    /** The operation bulletin of the polo shirt: time, machine, grade, precedence. */
    private List<OperationSpec> poloOperations() {
        return List.of(
                new OperationSpec("C01", "Cut panel check", 0.30, MachineType.MANUAL, 1, 1, List.of()),
                new OperationSpec("S01", "Shoulder join", 0.55, MachineType.OVERLOCK, 3, 2, List.of("C01")),
                new OperationSpec("S02", "Shoulder topstitch", 0.45, MachineType.PLAIN, 3, 3, List.of("S01")),
                new OperationSpec("P01", "Placket make", 0.95, MachineType.PLAIN, 4, 4, List.of("C01")),
                new OperationSpec("P02", "Placket attach", 0.85, MachineType.PLAIN, 4, 5, List.of("P01", "S02")),
                new OperationSpec("B01", "Collar make", 0.80, MachineType.PLAIN, 4, 6, List.of("C01")),
                new OperationSpec("B02", "Collar join", 0.75, MachineType.PLAIN, 4, 7, List.of("B01", "P02")),
                new OperationSpec("L01", "Sleeve attach", 0.90, MachineType.OVERLOCK, 4, 8, List.of("S02")),
                new OperationSpec("L02", "Armhole topstitch", 0.60, MachineType.FLATLOCK, 3, 9, List.of("L01")),
                new OperationSpec("S03", "Side seam", 1.10, MachineType.OVERLOCK, 4, 10, List.of("L02")),
                new OperationSpec("C02", "Sleeve hem", 0.50, MachineType.FLATLOCK, 3, 11, List.of("S03")),
                new OperationSpec("H01", "Bottom hem", 0.65, MachineType.PLAIN, 3, 12, List.of("S03")),
                new OperationSpec("BH1", "Button hole", 0.35, MachineType.BUTTON_HOLE, 3, 13, List.of("B02", "H01")),
                new OperationSpec("BA1", "Button attach", 0.40, MachineType.BUTTON_ATTACH, 3, 14, List.of("BH1")),
                new OperationSpec("T01", "Thread trim", 0.70, MachineType.MANUAL, 1, 15, List.of("BA1", "C02")),
                new OperationSpec("I01", "Iron and fold", 0.85, MachineType.IRON, 2, 16, List.of("T01")));
    }

    /** A simpler style, so the factory has more than one product in play. */
    private List<OperationSpec> teeOperations() {
        return List.of(
                new OperationSpec("C01", "Cut panel check", 0.25, MachineType.MANUAL, 1, 1, List.of()),
                new OperationSpec("S01", "Shoulder join", 0.50, MachineType.OVERLOCK, 3, 2, List.of("C01")),
                new OperationSpec("N01", "Neck rib attach", 0.65, MachineType.OVERLOCK, 4, 3, List.of("S01")),
                new OperationSpec("N02", "Neck topstitch", 0.45, MachineType.FLATLOCK, 3, 4, List.of("N01")),
                new OperationSpec("L01", "Sleeve attach", 0.80, MachineType.OVERLOCK, 4, 5, List.of("N02")),
                new OperationSpec("S02", "Side seam", 0.95, MachineType.OVERLOCK, 4, 6, List.of("L01")),
                new OperationSpec("H01", "Bottom hem", 0.60, MachineType.FLATLOCK, 3, 7, List.of("S02")),
                new OperationSpec("T01", "Thread trim and fold", 0.55, MachineType.MANUAL, 1, 8, List.of("H01")));
    }

    private record OperationSpec(String code,
                                 String name,
                                 double smv,
                                 MachineType machineType,
                                 int minGrade,
                                 int sequenceNo,
                                 List<String> predecessors) {
    }

    // ------------------------------------------------------------------
    // Lines, roster, accounts, orders
    // ------------------------------------------------------------------

    private ProductionLine seedLine(String code, String unit, int targetRatePerHour, Style style) {
        ProductionLine line = new ProductionLine(code, unit, 480, targetRatePerHour);
        line.setCurrentStyle(style);
        return lines.save(line);
    }

    private void seedRoster() {
        operators.saveAll(List.of(
                operator("OP01", "Rahima", 4, 0.85, MachineType.PLAIN, 1.05, MachineType.OVERLOCK, 0.80),
                operator("OP02", "Shirin", 4, 0.80, MachineType.OVERLOCK, 1.10, MachineType.FLATLOCK, 0.90),
                operator("OP03", "Nasima", 5, 0.90, MachineType.PLAIN, 1.15, MachineType.BUTTON_HOLE, 0.95),
                operator("OP04", "Parvin", 3, 0.75, MachineType.FLATLOCK, 1.00, MachineType.MANUAL, 1.10),
                operator("OP05", "Jesmin", 4, 0.85, MachineType.PLAIN, 0.95, MachineType.OVERLOCK, 1.00),
                operator("OP06", "Ruma", 3, 0.70, MachineType.MANUAL, 1.20, MachineType.IRON, 1.00),
                operator("OP07", "Sultana", 5, 0.95, MachineType.PLAIN, 1.20, MachineType.FLATLOCK, 0.85),
                operator("OP08", "Momena", 4, 0.80, MachineType.OVERLOCK, 1.05, MachineType.PLAIN, 0.90),
                operator("OP09", "Fatema", 3, 0.75, MachineType.BUTTON_ATTACH, 1.10, MachineType.BUTTON_HOLE, 1.05),
                operator("OP10", "Rekha", 4, 0.85, MachineType.PLAIN, 1.00, MachineType.IRON, 0.95),
                operator("OP11", "Anowara", 3, 0.70, MachineType.FLATLOCK, 0.95, MachineType.MANUAL, 1.05),
                operator("OP12", "Halima", 5, 0.90, MachineType.OVERLOCK, 1.15, MachineType.PLAIN, 1.00),
                operator("OP13", "Sabina", 4, 0.80, MachineType.PLAIN, 1.05, MachineType.BUTTON_ATTACH, 0.90),
                operator("OP14", "Morjina", 3, 0.75, MachineType.IRON, 1.15, MachineType.MANUAL, 1.00)));
    }

    private Operator operator(String code, String name, int grade, double defaultEfficiency,
                              MachineType firstMachine, double firstEfficiency,
                              MachineType secondMachine, double secondEfficiency) {
        Operator operator = new Operator(code, name, grade, defaultEfficiency);
        operator.addSkill(firstMachine, firstEfficiency);
        operator.addSkill(secondMachine, secondEfficiency);
        return operator;
    }

    private void seedEmployees(ProductionLine line) {
        String password = passwordEncoder.encode(properties.seed().demoPassword());

        Employee engineer = new Employee("IE-2214", "farhana.akter@seamline.com", password, "Farhana Akter",
                "Industrial Engineer", Role.INDUSTRIAL_ENGINEER);
        engineer.setAssignedLine(line);

        Employee supervisor = new Employee("SUP-1180", "kamal.hossain@seamline.com", password, "Kamal Hossain",
                "Production Supervisor", Role.SUPERVISOR);
        supervisor.setAssignedLine(line);

        Employee admin = new Employee("ADM-0001", "rezaul.karim@seamline.com", password, "S. M. Rezaul Karim",
                "Production Director", Role.ADMIN);
        admin.setAssignedLine(line);

        Employee operator = new Employee("MO-2201", "rahima.begum@seamline.com", password, "Rahima Begum",
                "Machine Operator", Role.OPERATOR);
        operator.setAssignedLine(line);

        employees.saveAll(List.of(engineer, supervisor, admin, operator));
    }

    private void seedOrders(Style polo, Style tee) {
        LocalDate today = LocalDate.now();

        Order first = new Order("PO-88214", "Nordfeld", 42000, 25620, today.plusDays(12));
        first.setStyle(polo);
        Order second = new Order("PO-88301", "Kloud Basics", 68000, 21760, today.plusDays(21));
        second.setStyle(tee);
        Order third = new Order("PO-88355", "Aveline", 18500, 15910, today.plusDays(6));
        third.setStyle(polo);
        Order fourth = new Order("PO-88402", "Northgate Retail", 90000, 12600, today.plusDays(38));
        fourth.setStyle(tee);

        orders.saveAll(List.of(first, second, third, fourth));
    }

    /**
     * One stored shift per line, each on its own seed, so the dashboard and the
     * factory-wide screens have real numbers the moment someone signs in.
     */
    private void seedShifts() {
        long seed = 42L;
        for (ProductionLine line : lines.findAllByOrderByCodeAsc()) {
            dashboardService.rerun(line.getCode(),
                    new RunRequest("rpw", RunRequest.DEFAULT_TEAM_SIZE, RunRequest.DEFAULT_BUFFER,
                            RunRequest.DEFAULT_VARIABILITY, seed),
                    null);
            seed += 59L;
        }
    }
}
