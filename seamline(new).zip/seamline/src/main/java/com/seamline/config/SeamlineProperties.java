package com.seamline.config;

import java.util.List;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * Type-safe binding of the {@code seamline.*} block in application.yml.
 * Records give immutable configuration objects for free.
 */
@ConfigurationProperties(prefix = "seamline")
public record SeamlineProperties(Jwt jwt, Cors cors, Seed seed, Google google, Mail mail, @DefaultValue Otp otp) {

    public record Jwt(String secret, long expirationMinutes) {
    }

    public record Cors(List<String> allowedOrigins) {
    }

    public record Seed(boolean enabled, String demoPassword) {
    }

    /** Google Sign-In. {@code clientId} is blank until an admin sets it; the front end hides the button then. */
    public record Google(String clientId) {
    }

    /** SMTP account used to email verification codes and approval notices. Blank until an admin sets it. */
    public record Mail(String host, int port, String username, String password) {
    }

    /**
     * Emailed verification codes.
     *
     * @param signInEnabled         also ask for an emailed code on every sign-in (off by default;
     *                              "forgot password" always uses a code)
     * @param validMinutes          how long a code stays valid
     * @param maxAttempts           wrong guesses allowed before the code is dead
     * @param resendCooldownSeconds minimum gap between two emails for the same code
     * @param maxSends              how many times one sign-in may resend its code
     * @param logCodes              also print each code to the server log — for demos whose
     *                              accounts have no real inbox; never enable in production
     */
    public record Otp(@DefaultValue("false") boolean signInEnabled,
                      @DefaultValue("10") int validMinutes,
                      @DefaultValue("5") int maxAttempts,
                      @DefaultValue("60") int resendCooldownSeconds,
                      @DefaultValue("5") int maxSends,
                      @DefaultValue("false") boolean logCodes) {
    }
}
