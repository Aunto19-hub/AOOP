package com.seamline.repository;

import com.seamline.domain.Employee;
import com.seamline.domain.OtpPurpose;
import com.seamline.domain.VerificationCode;
import java.time.Instant;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface VerificationCodeRepository extends JpaRepository<VerificationCode, Long> {

    Optional<VerificationCode> findByChallengeId(String challengeId);

    Optional<VerificationCode> findFirstByEmployeeAndPurposeOrderByIdDesc(Employee employee, OtpPurpose purpose);

    @Modifying
    @Query("delete from VerificationCode v where v.employee = :employee and v.purpose = :purpose")
    void deleteAllFor(@Param("employee") Employee employee, @Param("purpose") OtpPurpose purpose);

    @Modifying
    @Query("delete from VerificationCode v where v.employee = :employee")
    void deleteAllForEmployee(@Param("employee") Employee employee);

    /** Housekeeping: codes past their expiry are useless, so they don't need to stay in the table. */
    @Modifying
    @Query("delete from VerificationCode v where v.expiresAt < :cutoff")
    int deleteExpiredBefore(@Param("cutoff") Instant cutoff);
}
