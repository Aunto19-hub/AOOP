package com.seamline.service;

import com.seamline.domain.ProductionLine;
import com.seamline.domain.ShiftRun;
import com.seamline.dto.FactoryResponse;
import com.seamline.repository.OrderRepository;
import com.seamline.repository.ProductionLineRepository;
import com.seamline.repository.ShiftRunRepository;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Factory-wide read models: every line's latest shift, and the order book. */
@Service
public class FactoryService {

    private final ProductionLineRepository lines;
    private final ShiftRunRepository runs;
    private final OrderRepository orders;

    public FactoryService(ProductionLineRepository lines, ShiftRunRepository runs, OrderRepository orders) {
        this.lines = lines;
        this.runs = runs;
        this.orders = orders;
    }

    @Transactional(readOnly = true)
    public List<FactoryResponse.Line> allLines() {
        List<FactoryResponse.Line> rows = new ArrayList<>();
        for (ProductionLine line : lines.findAllByOrderByCodeAsc()) {
            Optional<ShiftRun> latest = runs.findFirstByLineOrderByRunAtDescIdDesc(line);
            int output = latest.map(ShiftRun::getPiecesProduced).orElse(0);
            double efficiency = latest.map(ShiftRun::getLineEfficiency).orElse(0d);
            int target = line.targetPiecesPerShift();

            rows.add(new FactoryResponse.Line(
                    line.getCode(),
                    line.getUnitName(),
                    line.getCurrentStyle() == null ? null : line.getCurrentStyle().getName(),
                    line.getTargetRatePerHour(),
                    output,
                    target,
                    Math.round(efficiency * 10d) / 10d,
                    status(output, target, latest.isPresent())));
        }
        return rows;
    }

    @Transactional(readOnly = true)
    public List<FactoryResponse.OrderRow> allOrders() {
        return orders.findAllByOrderByDueDateAsc().stream()
                .map(FactoryResponse.OrderRow::from)
                .toList();
    }

    /** A line is at risk when it is more than a tenth short of its shift target. */
    private String status(int output, int target, boolean hasRun) {
        if (!hasRun || target <= 0) {
            return "WATCH";
        }
        double ratio = output / (double) target;
        if (ratio >= 0.95) {
            return "HEALTHY";
        }
        return ratio >= 0.90 ? "WATCH" : "AT_RISK";
    }
}
