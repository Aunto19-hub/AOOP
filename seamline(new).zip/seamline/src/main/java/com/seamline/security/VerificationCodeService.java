package com.seamline.security;

import com.seamline.config.SeamlineProperties;
import com.seamline.domain.Employee;
import com.seamline.domain.OtpPurpose;
import com.seamline.domain.VerificationCode;
import com.seamline.dto.LoginChallenge;
import com.seamline.exception.InvalidCredentialsException;
import com.seamline.exception.OtpDeliveryException;
import com.seamline.exception.OtpThrottledException;
import com.seamline.repository.VerificationCodeRepository;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Optional;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Issues and checks the 6-digit codes emailed for sign-in and password reset.
 *
 * <p>Rules, all configurable under {@code seamline.otp}: a code expires after a
 * few minutes, dies after a handful of wrong guesses, can be used once, and
 * can't be re-sent faster than the cooldown. Only one live code exists per
 * account and purpose — issuing a new one deletes the old.</p>
 *
 * <p>Wrong guesses must be counted even though the request fails, so the
 * verify methods are marked {@code noRollbackFor} the exception they throw.</p>
 */
@Service
public class VerificationCodeService {

    private static final Logger log = LoggerFactory.getLogger(VerificationCodeService.class);

    private final VerificationCodeRepository codes;
    private final EmailService emailService;
    private final PasswordEncoder passwordEncoder;
    private final SeamlineProperties.Otp settings;

    public VerificationCodeService(VerificationCodeRepository codes,
                                   EmailService emailService,
                                   PasswordEncoder passwordEncoder,
                                   SeamlineProperties properties) {
        this.codes = codes;
        this.emailService = emailService;
        this.passwordEncoder = passwordEncoder;
        this.settings = properties.otp();
    }

    public boolean isSignInVerificationEnabled() {
        return settings.signInEnabled();
    }

    /** Fails loudly when there's no way at all to get a code to the person. */
    public void requireDeliverable() {
        if (!emailService.isConfigured() && !settings.logCodes()) {
            throw new OtpDeliveryException("Email verification is not configured on this server. "
                    + "Set SEAMLINE_MAIL_USERNAME and SEAMLINE_MAIL_PASSWORD.");
        }
    }

    /**
     * Emails a new code, unless one was sent moments ago and is still good — then
     * the existing challenge is returned and no second email goes out. That stops
     * repeated sign-in clicks or "forgot password" presses from flooding an inbox.
     */
    @Transactional
    public LoginChallenge issue(Employee employee, OtpPurpose purpose) {
        requireDeliverable();
        Instant now = Instant.now();
        codes.deleteExpiredBefore(now.minus(1, ChronoUnit.DAYS));

        Optional<VerificationCode> live = codes.findFirstByEmployeeAndPurposeOrderByIdDesc(employee, purpose)
                .filter(code -> code.isUsable(now, settings.maxAttempts())
                        && code.secondsUntilResend(now, settings.resendCooldownSeconds()) > 0);
        if (live.isPresent()) {
            return challengeFor(live.get(), now);
        }

        codes.deleteAllFor(employee, purpose);
        String plain = emailService.generateCode();
        VerificationCode code = new VerificationCode(employee, purpose, UUID.randomUUID().toString(),
                passwordEncoder.encode(plain), expiryFrom(now), now);
        codes.save(code);
        deliver(employee, purpose, plain);
        return challengeFor(code, now);
    }

    /** "Resend code" on the sign-in step: same challenge, new code, cooldown enforced. */
    @Transactional
    public LoginChallenge resend(String challengeId, OtpPurpose purpose) {
        requireDeliverable();
        Instant now = Instant.now();
        VerificationCode code = codes.findByChallengeId(challengeId)
                .filter(candidate -> candidate.getPurpose() == purpose)
                .filter(candidate -> candidate.isUsable(now, settings.maxAttempts()))
                .orElseThrow(() -> new InvalidCredentialsException("This sign-in has expired. Sign in again."));

        long wait = code.secondsUntilResend(now, settings.resendCooldownSeconds());
        if (wait > 0) {
            throw new OtpThrottledException(wait);
        }
        if (code.getSendCount() >= settings.maxSends()) {
            throw new InvalidCredentialsException("Too many codes requested. Sign in again.");
        }

        String plain = emailService.generateCode();
        code.replaceCode(passwordEncoder.encode(plain), expiryFrom(now), now);
        codes.save(code);
        deliver(code.getEmployee(), purpose, plain);
        return challengeFor(code, now);
    }

    /** Sign-in step 2: checks the code behind a challenge and returns whose it was. */
    @Transactional(noRollbackFor = InvalidCredentialsException.class)
    public Employee verifyChallenge(String challengeId, OtpPurpose purpose, String submitted) {
        VerificationCode code = codes.findByChallengeId(challengeId)
                .filter(candidate -> candidate.getPurpose() == purpose)
                .orElseThrow(() -> new InvalidCredentialsException("This sign-in has expired. Sign in again."));
        return check(code, submitted);
    }

    /** Password reset step 2: checks the newest code emailed to this account. */
    @Transactional(noRollbackFor = InvalidCredentialsException.class)
    public Employee verifyLatest(Employee employee, OtpPurpose purpose, String submitted) {
        VerificationCode code = codes.findFirstByEmployeeAndPurposeOrderByIdDesc(employee, purpose)
                .orElseThrow(() -> new InvalidCredentialsException("Invalid or expired code"));
        return check(code, submitted);
    }

    /** Drops any pending codes — e.g. a sign-in started with a password that was just reset. */
    @Transactional
    public void revokeAll(Employee employee, OtpPurpose purpose) {
        codes.deleteAllFor(employee, purpose);
    }

    private Employee check(VerificationCode code, String submitted) {
        Instant now = Instant.now();
        if (!code.isUsable(now, settings.maxAttempts())) {
            throw new InvalidCredentialsException("That code has expired or been used. Request a new one.");
        }
        if (submitted == null || !passwordEncoder.matches(submitted.trim(), code.getCodeHash())) {
            code.recordFailedAttempt();
            codes.save(code);
            int left = code.attemptsLeft(settings.maxAttempts());
            throw new InvalidCredentialsException(left > 0
                    ? "Incorrect code. " + left + (left == 1 ? " attempt" : " attempts") + " left."
                    : "Too many incorrect attempts. Request a new code.");
        }
        code.consume(now);
        codes.save(code);
        return code.getEmployee();
    }

    private void deliver(Employee employee, OtpPurpose purpose, String plain) {
        if (settings.logCodes()) {
            log.warn("[DEV ONLY] {} code for {} is {} (seamline.otp.log-codes=true)",
                    purpose.getLabel(), employee.getEmail(), plain);
        }
        if (emailService.isConfigured()) {
            emailService.sendVerificationCode(employee.getEmail(), purpose, plain, settings.validMinutes());
        }
    }

    private Instant expiryFrom(Instant now) {
        return now.plus(settings.validMinutes(), ChronoUnit.MINUTES);
    }

    private LoginChallenge challengeFor(VerificationCode code, Instant now) {
        return new LoginChallenge(code.getChallengeId(),
                maskEmail(code.getEmployee().getEmail()),
                code.secondsUntilExpiry(now),
                code.secondsUntilResend(now, settings.resendCooldownSeconds()));
    }

    /** "farhana.akter@seamline.com" → "f**********r@seamline.com", so the screen confirms the inbox without exposing it. */
    static String maskEmail(String email) {
        int at = email.indexOf('@');
        if (at <= 0) {
            return "your email";
        }
        String local = email.substring(0, at);
        String masked = local.length() <= 2
                ? local.charAt(0) + "*"
                : local.charAt(0) + "*".repeat(local.length() - 2) + local.charAt(local.length() - 1);
        return masked + email.substring(at);
    }
}
