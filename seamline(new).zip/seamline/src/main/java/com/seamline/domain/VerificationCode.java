package com.seamline.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.time.Duration;
import java.time.Instant;

/**
 * One emailed verification code — for a sign-in or a password reset. Only the
 * BCrypt hash of the code is stored. The {@code challengeId} is a random handle
 * the browser holds between "password accepted" and "code entered", so the
 * second step can't be reached without passing the first.
 *
 * <p>The rules a code lives by (expiry, attempt limit, single use, resend
 * cooldown) sit here with the data rather than in the service.</p>
 */
@Entity
@Table(name = "verification_codes")
public class VerificationCode extends BaseEntity {

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "employee_ref")
    private Employee employee;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private OtpPurpose purpose;

    @Column(name = "challenge_id", nullable = false, unique = true, length = 36)
    private String challengeId;

    @Column(name = "code_hash", nullable = false, length = 100)
    private String codeHash;

    @Column(name = "expires_at", nullable = false)
    private Instant expiresAt;

    @Column(name = "last_sent_at", nullable = false)
    private Instant lastSentAt;

    @Column(name = "failed_attempts", nullable = false)
    private int failedAttempts;

    @Column(name = "send_count", nullable = false)
    private int sendCount = 1;

    @Column(name = "consumed_at")
    private Instant consumedAt;

    protected VerificationCode() {
        // required by JPA
    }

    public VerificationCode(Employee employee, OtpPurpose purpose, String challengeId,
                            String codeHash, Instant expiresAt, Instant sentAt) {
        this.employee = employee;
        this.purpose = purpose;
        this.challengeId = challengeId;
        this.codeHash = codeHash;
        this.expiresAt = expiresAt;
        this.lastSentAt = sentAt;
    }

    /** Not yet used, not expired, and not locked by too many wrong guesses. */
    public boolean isUsable(Instant now, int maxAttempts) {
        return consumedAt == null && now.isBefore(expiresAt) && failedAttempts < maxAttempts;
    }

    public void recordFailedAttempt() {
        failedAttempts++;
    }

    public int attemptsLeft(int maxAttempts) {
        return Math.max(0, maxAttempts - failedAttempts);
    }

    public void consume(Instant now) {
        this.consumedAt = now;
    }

    /** Seconds before another email may go out for this code; 0 when a resend is allowed. */
    public long secondsUntilResend(Instant now, int cooldownSeconds) {
        long waited = Duration.between(lastSentAt, now).getSeconds();
        return Math.max(0, cooldownSeconds - waited);
    }

    /** "Resend code": a fresh code under the same challenge, with a fresh expiry and attempt count. */
    public void replaceCode(String newHash, Instant newExpiry, Instant now) {
        this.codeHash = newHash;
        this.expiresAt = newExpiry;
        this.lastSentAt = now;
        this.failedAttempts = 0;
        this.sendCount++;
    }

    public long secondsUntilExpiry(Instant now) {
        return Math.max(0, Duration.between(now, expiresAt).getSeconds());
    }

    public Employee getEmployee() {
        return employee;
    }

    public OtpPurpose getPurpose() {
        return purpose;
    }

    public String getChallengeId() {
        return challengeId;
    }

    public String getCodeHash() {
        return codeHash;
    }

    public int getSendCount() {
        return sendCount;
    }
}
