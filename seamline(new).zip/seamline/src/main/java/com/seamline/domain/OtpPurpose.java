package com.seamline.domain;

/** Why a verification code was emailed. A code issued for one purpose can never be spent on another. */
public enum OtpPurpose {

    SIGN_IN("sign-in"),
    PASSWORD_RESET("password reset");

    private final String label;

    OtpPurpose(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
