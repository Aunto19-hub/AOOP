package com.seamline;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.seamline.domain.OtpPurpose;
import com.seamline.security.EmailService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

/**
 * Email verification: password reset (always on) and the optional sign-in code
 * step, switched on here so it stays tested. The mail sender is mocked
 * so every "emailed" code is a known 123456. Each test uses its own seeded
 * account so their codes and cooldowns never collide.
 */
@SpringBootTest(properties = {"seamline.otp.sign-in-enabled=true", "seamline.otp.log-codes=false"})
@AutoConfigureMockMvc
class LoginVerificationIT {

    private static final String CODE = "123456";
    private static final String PASSWORD = "seamline123";

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private EmailService emailService;

    @BeforeEach
    void mailWorksAndCodesAreKnown() {
        when(emailService.isConfigured()).thenReturn(true);
        when(emailService.generateCode()).thenReturn(CODE);
    }

    @Test
    void passwordAloneGivesAChallengeNotAToken() throws Exception {
        postJson("/api/auth/login", login("farhana.akter@seamline.com", PASSWORD))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.otpRequired").value(true))
                .andExpect(jsonPath("$.login").doesNotExist())
                .andExpect(jsonPath("$.challenge.challengeId").isNotEmpty())
                .andExpect(jsonPath("$.challenge.maskedEmail").value("f***********r@seamline.com"));

        verify(emailService).sendVerificationCode(eq("farhana.akter@seamline.com"),
                eq(OtpPurpose.SIGN_IN), eq(CODE), anyInt());
    }

    @Test
    void wrongPasswordSendsNoEmail() throws Exception {
        postJson("/api/auth/login", login("farhana.akter@seamline.com", "nope-nope"))
                .andExpect(status().isUnauthorized());
        verify(emailService, never()).sendVerificationCode(eq("farhana.akter@seamline.com"),
                any(), any(), anyInt());
    }

    @Test
    void theRightCodeSignsInAndCannotBeReused() throws Exception {
        String challenge = startSignIn("farhana.akter@seamline.com");

        String body = postJson("/api/auth/login/verify", verifyBody(challenge, CODE))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.accessToken").isNotEmpty())
                .andReturn().getResponse().getContentAsString();
        String token = objectMapper.readTree(body).path("accessToken").asText();

        mockMvc.perform(get("/api/auth/me").header("Authorization", "Bearer " + token))
                .andExpect(status().isOk());

        postJson("/api/auth/login/verify", verifyBody(challenge, CODE))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void fiveWrongCodesLockTheChallenge() throws Exception {
        String challenge = startSignIn("kamal.hossain@seamline.com");

        for (int i = 0; i < 4; i++) {
            postJson("/api/auth/login/verify", verifyBody(challenge, "000000"))
                    .andExpect(status().isUnauthorized())
                    .andExpect(jsonPath("$.message").value("Incorrect code. " + (4 - i)
                            + (4 - i == 1 ? " attempt" : " attempts") + " left."));
        }
        postJson("/api/auth/login/verify", verifyBody(challenge, "000000"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.message").value("Too many incorrect attempts. Request a new code."));

        // Even the right code is refused now; the person has to start over with their password.
        postJson("/api/auth/login/verify", verifyBody(challenge, CODE))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void resendIsThrottled() throws Exception {
        String challenge = startSignIn("rahima.begum@seamline.com");

        postJson("/api/auth/login/resend", "{\"challengeId\":\"" + challenge + "\"}")
                .andExpect(status().isTooManyRequests());
    }

    @Test
    void anInventedChallengeIsRejected() throws Exception {
        postJson("/api/auth/login/verify", verifyBody("00000000-0000-0000-0000-000000000000", CODE))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void forgotPasswordNeedsTheEmailedCode() throws Exception {
        String identifier = "rezaul.karim@seamline.com";
        postJson("/api/auth/forgot-password", "{\"identifier\":\"" + identifier + "\"}")
                .andExpect(status().isOk());
        verify(emailService).sendVerificationCode(eq(identifier), eq(OtpPurpose.PASSWORD_RESET), eq(CODE), anyInt());

        postJson("/api/auth/reset-password", reset(identifier, "999999"))
                .andExpect(status().isUnauthorized());
        // Reset back to the demo password so other test classes are unaffected.
        postJson("/api/auth/reset-password", reset(identifier, CODE))
                .andExpect(status().isOk());
        postJson("/api/auth/reset-password", reset(identifier, CODE))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void forgotPasswordLooksTheSameForUnknownAccounts() throws Exception {
        postJson("/api/auth/forgot-password", "{\"identifier\":\"nobody@example.com\"}")
                .andExpect(status().isOk());
    }

    private String startSignIn(String email) throws Exception {
        String body = postJson("/api/auth/login", login(email, PASSWORD))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        JsonNode node = objectMapper.readTree(body);
        return node.path("challenge").path("challengeId").asText();
    }

    private ResultActions postJson(String path, String json) throws Exception {
        return mockMvc.perform(post(path).contentType(MediaType.APPLICATION_JSON).content(json));
    }

    private static String login(String identifier, String password) {
        return "{\"identifier\":\"" + identifier + "\",\"password\":\"" + password + "\"}";
    }

    private static String verifyBody(String challengeId, String code) {
        return "{\"challengeId\":\"" + challengeId + "\",\"code\":\"" + code + "\"}";
    }

    private static String reset(String identifier, String code) {
        return "{\"identifier\":\"" + identifier + "\",\"code\":\"" + code + "\",\"newPassword\":\"" + PASSWORD + "\"}";
    }
}
